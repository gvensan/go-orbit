# Orbit

A local-first Electron desktop CRM that stores contacts as an **encrypted
relationship graph**. Two primary surfaces — a forgiving search palette and an
interactive WebGL graph. Single-device, offline, corruption-proof, private.

Target scale: **20,000 contacts, ~200,000 edges.**

## Quick start

```bash
npm install          # installs deps + rebuilds the native module for Electron
npm run migrate      # create/upgrade the local DB schema
npm run fixture      # (optional) seed a 20k-contact test DB
npm run dev          # launch the app
```

Requires Node ≥ 20.

## What to read

Start with **`CLAUDE.md`** (repo orientation + guardrails), then the docs:

| Doc | Covers |
|---|---|
| `docs/APP_REQUIREMENTS.md` | Umbrella: features (must/need/nice), stack, schema, roadmap |
| `docs/INTERFACE_CONTRACT.md` | IPC channels, payloads, shared types — the boundary |
| `docs/SEARCH_REQUIREMENTS.md` | Fuzzy search: two-stage retrieval, ranking, acceptance tests |
| `docs/GRAPH_CANVAS_REQUIREMENTS.md` | WebGL graph: renderer, interactions, analytics |
| `docs/EXPORT_IMPORT_REQUIREMENTS.md` | Portable archive: format, encryption, device migration |
| `docs/DEDUP_MERGE_REQUIREMENTS.md` | Identity resolution and safe merge |
| `docs/APP_SHELL_UX.md` | Screen map, design system, keyboard model, error states |
| `docs/BUILD_AND_RELEASE.md` | Cross-platform build, signing, auto-update |
| `docs/TEST_STRATEGY.md` | Test layers, fixtures, recovery harness |
| `docs/SECURITY_AND_THREAT_MODEL.md` | Threat model, encryption, key management |

## Architecture at a glance

- **Electron**, hardened renderer (contextIsolation, sandbox, validated IPC).
- **SQLite/SQLCipher** (`better-sqlite3-multiple-ciphers`), one encrypted file, WAL.
- **graphology** in-memory model; **sigma.js** (WebGL) renderer; force layout + betweenness on workers.
- **FTS5 + JS fuzzy re-rank** for search, on a read-only worker connection.
- Lifecycle, self-healing DB open, and backups in `src/main/main.js`.

## Milestones

- **M0** Foundation — lifecycle, schema + migrations, encrypted DB, backup/restore.
- **M1** Core data — CRUD, soft-delete, edges, tags, interactions, graph hydration.
- **M2** Ingest — vCard/CSV import, export archive, dedup-on-import.
- **M3** Graph — renderer, interactions, worker layout.
- **M4** Search — index, pipeline, command palette.
- **M5** Intelligence — analytics, clustering, search↔graph, dedup/merge UI.
- **M6** Distribution & hardening — CI build matrix, signing, updates, logging, tests.

## Layout

```
src/main/      lifecycle, IPC, DB, config, backups
src/shared/    types.d.ts — the domain + IPC contract
src/renderer/  UI (built per docs/APP_SHELL_UX.md and the graph/search specs)
scripts/       generate-fixture.js
docs/          all specifications
```

## Guardrails (full list in CLAUDE.md)

Never run layout/betweenness on the main thread. Never write a plaintext index.
Never hard-cascade a user delete. Every multi-statement write is a transaction.
Back up before every migration. The renderer is untrusted.
