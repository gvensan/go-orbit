# Interface Contract — IPC & Shared Types

**Status:** Authoritative. Build renderer, main, and workers against this.
**Types:** `src/shared/types.d.ts` (imported by both sides).

The renderer never touches SQLite, the filesystem, or a worker directly. It
speaks only to the main process, over the channels below, through the preload
bridge. This is both a security boundary (untrusted renderer) and the seam that
lets main, renderer, and workers be built independently.

## 1. Boundary rules

- The preload script (`src/main/preload.js`) exposes exactly one namespaced API on `window.api`, one method per channel. No raw `ipcRenderer`, no Node globals, reach the renderer.
- Every channel is request/response via `ipcRenderer.invoke` / `ipcMain.handle` — promise-based, so the renderer awaits typed results.
- The main process **validates every request payload** against its declared shape before acting. Invalid payloads reject with `IpcError { code: "VALIDATION" }`. Never trust a payload because the renderer "should" have sent the right thing.
- Responses and rejections use the shapes in `types.d.ts`. Errors always reject with `IpcError`; they are never resolved as a success value.

## 2. Channel catalogue

The full map is `IpcContract` in `types.d.ts`. Summary of who does the work and on which thread:

| Channel | Runs where | Notes |
|---|---|---|
| `contacts:*` | main, sync | `better-sqlite3` synchronous CRUD in a transaction |
| `edges:*` | main, sync | validates both endpoints exist and are live |
| `interactions:*` | main, sync | feeds search recency ranking |
| `graph:snapshot` | main, sync | hydrates `nodes`/`links` from SQLite for the renderer |
| `graph:ego` | main (graphology) | BFS to depth N over the in-memory graph |
| `graph:path` | main (graphology) | shortest path; cheap |
| `graph:centrality` (degree) | main | precomputed/trivial |
| `graph:centrality` (betweenness) | **worker** | O(V·E); on-demand; cached; never main thread |
| `search:query` | **search worker** | read-only connection; two-stage retrieval; cancellable |
| `backup:now` | main, sync | `VACUUM INTO` + verify + rotate |
| `export:archive` | main (may offload) | serialize + optional passphrase encryption |
| `import:archive` | main | validate version → dedup → merge |

Force layout is not a request/response channel — it is a worker that streams
node positions to the renderer via an event channel (`graph:layout:tick`), which
the renderer subscribes to and unsubscribes from. Positions are persisted so
reopening is instant.

## 3. Cancellation

`search:query` carries a monotonic `requestId`. The renderer increments it per
keystroke (after debounce). The search worker tags each `SearchResponse` with
the originating `requestId`; the renderer discards any response whose id is not
the latest. The worker may also abandon in-flight work when a newer id arrives.

## 4. Error semantics

| Code | Meaning |
|---|---|
| `VALIDATION` | Payload failed shape/bounds checks. Never reached the data layer. |
| `NOT_FOUND` | Referenced id does not exist or is soft-deleted. |
| `CONFLICT` | Uniqueness or edge-duplicate violation. |
| `LOCKED` | DB busy beyond `busy_timeout`, or a restore/migration is in progress. |
| `INTERNAL` | Unexpected; logged with a correlation id, message scrubbed of PII. |

The renderer maps these to the UX states in `docs/APP_SHELL_UX.md` (§ error &
recovery). It never shows a raw stack trace.

## 5. Adding a channel

1. Add the entry to `IpcContract` in `types.d.ts` (request + response shapes).
2. Register a validated `ipcMain.handle` in the main process.
3. Expose one method on `window.api` in `preload.js`.
4. Decide the thread: anything O(V·E) or heavier than a point query goes to a worker with its own read-only connection.
5. Add it to the table in §2 and cover it in tests.

Never widen the bridge with a generic passthrough. One method per channel, typed
and validated, is the whole point.
