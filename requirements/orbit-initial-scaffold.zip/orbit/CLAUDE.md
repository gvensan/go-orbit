# CLAUDE.md

Read this first, every session. It orients you before you touch code.

## What this is

Orbit — an Electron desktop CRM that stores contacts as a relationship
graph. Local-first, single-device, offline, encrypted at rest. Two primary
surfaces: a forgiving search palette and an interactive WebGL graph. Target
scale: 20,000 contacts, ~200,000 edges.

Full intent and feature tiers: `docs/APP_REQUIREMENTS.md`.

## Read order

1. `docs/APP_REQUIREMENTS.md` — umbrella: features (must/need/nice), stack, schema, roadmap.
2. `docs/INTERFACE_CONTRACT.md` — IPC channels, payload/return shapes, shared types. **Build against this, not against your own assumptions.**
3. The spec for whatever you're building: `SEARCH_REQUIREMENTS.md`, `GRAPH_CANVAS_REQUIREMENTS.md`, `EXPORT_IMPORT_REQUIREMENTS.md`, `DEDUP_MERGE_REQUIREMENTS.md`, `APP_SHELL_UX.md`.
4. `docs/TEST_STRATEGY.md` for how to prove it, `docs/BUILD_AND_RELEASE.md` for shipping, `docs/SECURITY_AND_THREAT_MODEL.md` for the privacy contract.

## Language & conventions

- **JavaScript, CommonJS** (`require`/`module.exports`) — matches `src/main/main.js`. TypeScript is acceptable if you migrate the whole tree, but do not mix.
- Domain and IPC types are declared in `src/shared/types.d.ts`. Treat them as the contract even in JS; annotate with JSDoc `@type` imports.
- All tunables live in `src/main/config.js`. Never hardcode a weight, interval, or threshold elsewhere.
- Node ≥ 20, npm.

## Commands

```
npm install            # includes electron-rebuild for the native module
npm run migrate        # apply pending DB migrations
npm run dev            # launch Electron with the local renderer
npm run fixture        # generate a 20k-contact test DB (scripts/generate-fixture.js)
npm test               # unit + acceptance suite
npm run build          # electron-builder for the current OS
```

## Repo layout

```
src/main/        Electron main process: lifecycle, IPC, DB, backups, workers spawn
  main.js        Lifecycle orchestrator — boot order + teardown. Reference, don't duplicate.
  preload.js     The ONLY IPC bridge. contextIsolation stays on.
  config.js      All tunables.
  db/            migrate.js runner + migrations/*.sql
src/shared/      types.d.ts — domain + IPC contract types, imported by both sides
src/renderer/    UI (search palette, graph canvas, contact views) — sigma.js lives here
scripts/         generate-fixture.js and other dev tooling
test/            unit + acceptance; fixtures/ holds seeded + corrupt DBs
docs/            all specifications
```

Workers (force layout, betweenness, search) live under `src/main/` or a
`src/workers/` you create; they own their own read-only SQLite connections.

## Non-negotiable guardrails

These are correctness and safety constraints, not style preferences. Violating
any of them is a defect regardless of whether tests pass.

- **Never run force layout or betweenness centrality on the main thread.** Both are worker-only. Betweenness is O(V·E) at 20k — compute on demand, cache it.
- **Never write a plaintext search index or plaintext DB to disk.** Everything lives inside the SQLCipher-encrypted file.
- **Never hard-cascade a user-initiated delete.** Use soft-delete (`deleted_at`) + a recoverable trash view. `ON DELETE CASCADE` in the schema is for integrity of *derived* rows only.
- **Every multi-statement write is a transaction.** Use `db.transaction()`.
- **Take a `VACUUM INTO` backup before every migration.** A half-applied migration is the corruption case this app exists to prevent.
- **All read paths filter `deleted_at IS NULL`.**
- **Renderer is untrusted.** contextIsolation on, sandbox on, nodeIntegration off, strict CSP, no remote content. IPC payloads are validated in the main process before use.
- **One writer.** The single-instance lock is boot-critical; two processes on one SQLite file corrupt it.

## Definition of done (per unit of work)

1. Behavior matches the relevant spec section.
2. Acceptance tests for that behavior pass (see the spec's §12 and `docs/TEST_STRATEGY.md`).
3. No guardrail above is violated.
4. Tunables are in `config.js`; types match `types.d.ts`.
5. A short note in the PR/commit on which spec section it satisfies.

## Assumptions made at scaffold time (override if wrong)

JavaScript/CommonJS, npm, GitHub Actions CI, GitHub Releases as the update feed,
`better-sqlite3-multiple-ciphers` for SQLCipher, `sigma.js` v3 for rendering.
These are stated so they're visible; change them deliberately, not by drift.
