// boot.js — renderer smoke test. Confirms the preload bridge and data layer
// are alive. Replace with the real app shell (APP_SHELL_UX.md).

(async () => {
  const probe = document.getElementById("probe");
  try {
    const contacts = await window.api.contacts.list({});
    probe.textContent = `Data layer OK — ${contacts.length} contacts.`;
  } catch (err) {
    probe.textContent = `Data layer error: ${err.message}`;
  }
})();
