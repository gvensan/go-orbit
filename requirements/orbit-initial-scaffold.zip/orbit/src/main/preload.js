// preload.js — the ONLY bridge between renderer and main.
//
// contextIsolation is on, so the renderer sees exactly `window.api` and nothing
// else. One method per IPC channel (see docs/INTERFACE_CONTRACT.md). No raw
// ipcRenderer, no Node globals, cross this boundary.

const { contextBridge, ipcRenderer } = require("electron");

/** Wrap invoke so every call is a typed, promise-returning method. */
const invoke = (channel) => (payload) => ipcRenderer.invoke(channel, payload ?? {});

const api = {
  contacts: {
    list: invoke("contacts:list"),
    get: invoke("contacts:get"),
    create: invoke("contacts:create"),
    update: invoke("contacts:update"),
    softDelete: invoke("contacts:softDelete"),
    restore: invoke("contacts:restore"),
  },
  edges: {
    create: invoke("edges:create"),
    delete: invoke("edges:delete"),
  },
  interactions: {
    list: invoke("interactions:list"),
    add: invoke("interactions:add"),
  },
  graph: {
    snapshot: invoke("graph:snapshot"),
    ego: invoke("graph:ego"),
    path: invoke("graph:path"),
    centrality: invoke("graph:centrality"),
    // Layout is a streamed event channel, not request/response.
    onLayoutTick: (cb) => {
      const listener = (_e, positions) => cb(positions);
      ipcRenderer.on("graph:layout:tick", listener);
      return () => ipcRenderer.removeListener("graph:layout:tick", listener);
    },
  },
  search: {
    query: invoke("search:query"),
  },
  data: {
    backupNow: invoke("backup:now"),
    exportArchive: invoke("export:archive"),
    importArchive: invoke("import:archive"),
  },
};

contextBridge.exposeInMainWorld("api", api);
