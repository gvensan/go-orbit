// config.js — the ONE place tunables live. Never hardcode these elsewhere.

module.exports = {
  window: {
    width: 1200,
    height: 800,
    minWidth: 900,   // below this the two-column layout breaks (see APP_SHELL_UX)
    minHeight: 600,
  },

  db: {
    filename: "contacts.db",
    // synchronous=NORMAL is WAL-safe; FULL only if last-write power-loss durability is required
    pragmas: {
      journal_mode: "WAL",
      synchronous: "NORMAL",
      foreign_keys: "ON",
      busy_timeout: 5000,
    },
  },

  backup: {
    dirName: "backups",
    intervalMs: 15 * 60 * 1000, // periodic snapshot
    keep: 10,                   // rotation depth
    onExit: true,               // best-effort final snapshot (never blocks quit)
  },

  search: {
    debounceMs: 120,
    candidateK: 200,            // FTS candidates handed to the fuzzy re-rank
    limit: 20,                  // results returned to the UI
    // Field weights for BM25 (name highest). Centralized so ranking is tunable.
    fieldWeights: { name: 10, email: 6, phone: 6, tags: 5, company: 4, role: 4, notes: 2 },
    // Re-rank blend + signal boosts.
    rerank: { wBm25: 0.45, wName: 0.30, wRecency: 0.15, wDegree: 0.10 },
    exactBoost: 0.25,
    prefixBoost: 0.12,
  },

  graph: {
    forceAtlas2: { iterations: 600, settleAlpha: 0.02 },
    lodLabelZoom: 1.4,          // labels appear above this zoom
    lodLabelMinDegree: 10,      // ...or for hubs at any zoom
    betweennessCacheTtlMs: 60 * 60 * 1000,
  },

  security: {
    // Renderer hardening — asserted at window creation.
    contextIsolation: true,
    sandbox: true,
    nodeIntegration: false,
    csp: "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'none'",
  },

  update: {
    enabled: true,
    // GitHub Releases feed is wired in electron-builder.yml (publish).
    backupBeforeApply: true,
  },
};
