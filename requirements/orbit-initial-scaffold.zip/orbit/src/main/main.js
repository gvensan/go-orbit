// main.js — Electron main process lifecycle orchestrator
//
// Startup order (dependency order):   lock → database → graph → services → UI
// Shutdown order (strict reverse):    UI → services → graph → database → release
//
// The database comes up first and goes down last so durability is always
// guaranteed. Teardown is idempotent and wired to every exit path so the app
// never leaves a dangling WAL behind (the main local-corruption risk).

const { app, BrowserWindow, ipcMain } = require("electron");
const Database = require("better-sqlite3");
const Graph = require("graphology");
const fs = require("fs");
const path = require("path");

// ---------------------------------------------------------------------------
// Shared runtime state (the "components")
// ---------------------------------------------------------------------------
const USER_DATA = app.getPath("userData");
const DB_PATH = path.join(USER_DATA, "contacts.db");
const BACKUP_DIR = path.join(USER_DATA, "backups");
const BACKUP_INTERVAL_MS = 15 * 60 * 1000; // periodic snapshot
const BACKUP_KEEP = 10; // rotation depth

const runtime = {
  db: null,
  graph: null,
  backupTimer: null,
  window: null,
};

let shuttingDown = false; // teardown re-entrancy guard

// ===========================================================================
// COMPONENT: database (self-healing open)
// ===========================================================================
function openDatabaseWithSelfHeal(dbPath, backupDir) {
  fs.mkdirSync(backupDir, { recursive: true });

  const applyPragmas = (db) => {
    db.pragma("journal_mode = WAL");
    db.pragma("synchronous = NORMAL");
    db.pragma("foreign_keys = ON");
    db.pragma("busy_timeout = 5000");
  };

  const isHealthy = (db) => {
    try {
      return db.pragma("quick_check", { simple: true }) === "ok";
    } catch {
      return false;
    }
  };

  // Attempt normal open + integrity check.
  if (fs.existsSync(dbPath)) {
    try {
      const db = new Database(dbPath);
      applyPragmas(db);
      if (isHealthy(db)) return db;
      db.close();
      console.error("[db] quick_check failed — attempting restore");
    } catch (e) {
      console.error("[db] open failed — attempting restore:", e.message);
    }

    // Corrupt: quarantine the bad file, restore newest good snapshot.
    const restored = restoreNewestGoodBackup(dbPath, backupDir);
    if (!restored) {
      // No good backup — quarantine and start clean so the app still boots.
      try {
        fs.renameSync(dbPath, dbPath + `.corrupt-${Date.now()}`);
      } catch {}
    }
  }

  const db = new Database(dbPath);
  applyPragmas(db);
  ensureSchema(db);
  return db;
}

function restoreNewestGoodBackup(dbPath, backupDir) {
  const snaps = listBackups(backupDir); // newest first
  for (const snap of snaps) {
    try {
      const probe = new Database(snap, { readonly: true });
      const ok = probe.pragma("integrity_check", { simple: true }) === "ok";
      probe.close();
      if (!ok) continue;
      try {
        fs.renameSync(dbPath, dbPath + `.corrupt-${Date.now()}`);
      } catch {}
      for (const ext of ["-wal", "-shm"]) {
        try { fs.unlinkSync(dbPath + ext); } catch {}
      }
      fs.copyFileSync(snap, dbPath);
      console.warn("[db] restored from backup:", path.basename(snap));
      return true;
    } catch {
      /* try older snapshot */
    }
  }
  return false;
}

function ensureSchema(db) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS contacts (
      id      INTEGER PRIMARY KEY,
      name    TEXT NOT NULL,
      fields  TEXT            -- flexible JSON schema
    );
    CREATE TABLE IF NOT EXISTS edges (
      source_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
      target_id INTEGER NOT NULL REFERENCES contacts(id) ON DELETE CASCADE,
      type      TEXT NOT NULL,
      directed  INTEGER NOT NULL DEFAULT 0,
      metadata  TEXT,
      PRIMARY KEY (source_id, target_id, type)
    );
    CREATE INDEX IF NOT EXISTS idx_edges_source ON edges(source_id);
    CREATE INDEX IF NOT EXISTS idx_edges_target ON edges(target_id);
  `);
}

// ===========================================================================
// COMPONENT: in-memory graph (hydrated from SQLite)
// ===========================================================================
function hydrateGraph(db) {
  const graph = new Graph({ multi: true, type: "mixed" });
  for (const c of db.prepare("SELECT id, name FROM contacts").iterate()) {
    graph.addNode(c.id, { name: c.name });
  }
  for (const e of db
    .prepare("SELECT source_id, target_id, type FROM edges")
    .iterate()) {
    // tolerate edges whose endpoints were filtered out
    if (graph.hasNode(e.source_id) && graph.hasNode(e.target_id)) {
      graph.addEdge(e.source_id, e.target_id, { type: e.type });
    }
  }
  console.log(`[graph] hydrated ${graph.order} nodes / ${graph.size} edges`);
  return graph;
}

// ===========================================================================
// COMPONENT: backup service (VACUUM INTO snapshots + verify + rotate)
// ===========================================================================
function listBackups(backupDir) {
  if (!fs.existsSync(backupDir)) return [];
  return fs
    .readdirSync(backupDir)
    .filter((f) => f.endsWith(".db"))
    .map((f) => path.join(backupDir, f))
    .sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs);
}

function takeBackup(db, backupDir) {
  fs.mkdirSync(backupDir, { recursive: true });
  const dest = path.join(backupDir, `contacts-${Date.now()}.db`);
  const tmp = dest + ".tmp";
  db.exec(`VACUUM INTO '${tmp.replace(/'/g, "''")}'`);

  const snap = new Database(tmp, { readonly: true });
  const ok = snap.pragma("integrity_check", { simple: true }) === "ok";
  snap.close();
  if (!ok) {
    fs.unlinkSync(tmp);
    throw new Error("snapshot failed integrity check");
  }
  fs.renameSync(tmp, dest); // atomic — never a half-written backup

  // rotate
  const snaps = listBackups(backupDir);
  for (const old of snaps.slice(BACKUP_KEEP)) {
    try { fs.unlinkSync(old); } catch {}
  }
  return dest;
}

function startBackupScheduler(db, backupDir) {
  const tick = () => {
    try {
      const f = takeBackup(db, backupDir);
      console.log("[backup]", path.basename(f));
    } catch (e) {
      console.error("[backup] failed:", e.message);
    }
  };
  const timer = setInterval(tick, BACKUP_INTERVAL_MS);
  timer.unref?.(); // never keep the process alive just for backups
  return timer;
}

// ===========================================================================
// COMPONENT: IPC surface (renderer ↔ data layer)
// ===========================================================================
function registerIpc(db, graph) {
  ipcMain.handle("contacts:list", () =>
    db.prepare("SELECT id, name, fields FROM contacts").all()
  );
  ipcMain.handle("graph:ego", (_e, id, depth = 1) => {
    // breadth-limited neighborhood from the in-memory graph
    const seen = new Set([id]);
    let frontier = [id];
    for (let d = 0; d < depth; d++) {
      const next = [];
      for (const n of frontier)
        graph.forEachNeighbor(n, (nb) => {
          if (!seen.has(nb)) { seen.add(nb); next.push(nb); }
        });
      frontier = next;
    }
    return [...seen];
  });
  ipcMain.handle("backup:now", () => takeBackup(db, BACKUP_DIR));
}

// ===========================================================================
// COMPONENT: window (UI) — created last, after data layer is ready
// ===========================================================================
function createWindow() {
  const win = new BrowserWindow({
    width: 1200,
    height: 800,
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      preload: path.join(__dirname, "preload.js"),
    },
  });
  win.once("ready-to-show", () => win.show());
  win.loadFile(path.join(__dirname, "renderer", "index.html"));
  return win;
}

// ===========================================================================
// BOOT — ordered, fail-fast
// ===========================================================================
function boot() {
  runtime.db = openDatabaseWithSelfHeal(DB_PATH, BACKUP_DIR); // 1. durable store
  runtime.graph = hydrateGraph(runtime.db);                   // 2. query layer
  runtime.backupTimer = startBackupScheduler(runtime.db, BACKUP_DIR); // 3. services
  registerIpc(runtime.db, runtime.graph);                     // 4. wire IPC
  runtime.window = createWindow();                            // 5. UI last
  console.log("[boot] all components up");
}

// ===========================================================================
// TEARDOWN — idempotent, synchronous, strict reverse order
// ===========================================================================
function teardown() {
  if (shuttingDown) return;
  shuttingDown = true;
  console.log("[shutdown] tearing down components");

  // services: stop taking new snapshots
  if (runtime.backupTimer) {
    clearInterval(runtime.backupTimer);
    runtime.backupTimer = null;
  }

  // database: final snapshot (best-effort) → checkpoint → close
  if (runtime.db) {
    try { takeBackup(runtime.db, BACKUP_DIR); } catch (e) {
      console.error("[shutdown] final backup skipped:", e.message);
    }
    try {
      runtime.db.pragma("wal_checkpoint(TRUNCATE)"); // fold WAL back, clean sidecars
      runtime.db.close();                            // release file handle
    } catch (e) {
      console.error("[shutdown] db close error:", e.message);
    }
    runtime.db = null;
  }

  runtime.graph = null; // release in-memory graph
  console.log("[shutdown] clean");
}

// ===========================================================================
// LIFECYCLE WIRING — cover every exit path
// ===========================================================================

// Single-instance lock: two processes on one SQLite file can corrupt it.
if (!app.requestSingleInstanceLock()) {
  app.quit();
} else {
  app.on("second-instance", () => {
    if (runtime.window) {
      if (runtime.window.isMinimized()) runtime.window.restore();
      runtime.window.focus();
    }
  });

  app.whenReady().then(boot);

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0 && !shuttingDown) {
      runtime.window = createWindow();
    }
  });

  app.on("window-all-closed", () => {
    if (process.platform !== "darwin") app.quit();
  });

  // Normal quit path — synchronous teardown, no async dance needed.
  app.on("before-quit", teardown);

  // Safety nets: OS signals and fatal errors still flush + close the DB.
  const hardExit = (code) => { teardown(); process.exit(code); };
  process.on("SIGINT", () => hardExit(0));
  process.on("SIGTERM", () => hardExit(0));
  process.on("uncaughtException", (err) => {
    console.error("[fatal]", err);
    hardExit(1);
  });
}
