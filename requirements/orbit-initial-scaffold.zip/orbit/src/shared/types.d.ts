/**
 * Shared domain + IPC contract types for Orbit.
 *
 * This file is the authoritative boundary between the main process, the
 * renderer, and the workers. Both sides import these shapes. In JS files,
 * reference them with JSDoc: `/** @type {import('../shared/types').Contact} *​/`.
 *
 * Every IPC channel below has a request payload and a response shape. The main
 * process validates the payload against these before acting. See
 * docs/INTERFACE_CONTRACT.md for the prose contract and error semantics.
 */

// ---------------------------------------------------------------------------
// Domain
// ---------------------------------------------------------------------------

/** Unix epoch milliseconds. */
export type Timestamp = number;

export interface Contact {
  id: number;
  name: string;
  /** Flexible per-contact attributes (email, phone, company, role, custom). */
  fields: ContactFields;
  createdAt: Timestamp;
  updatedAt: Timestamp;
  /** Null when live; set when soft-deleted. */
  deletedAt: Timestamp | null;
}

export interface ContactFields {
  email?: string;
  phone?: string;
  company?: string;
  role?: string;
  notes?: string;
  [key: string]: string | undefined; // custom fields
}

export type EdgeType = "colleague" | "family" | "introduced" | "friend" | string;

export interface Edge {
  sourceId: number;
  targetId: number;
  type: EdgeType;
  directed: boolean;
  metadata?: Record<string, unknown>;
  createdAt: Timestamp;
}

export interface Interaction {
  id: number;
  contactId: number;
  occurredAt: Timestamp;
  kind?: string; // call | email | meeting | note ...
  note?: string;
}

export interface Tag {
  id: number;
  name: string;
}

// ---------------------------------------------------------------------------
// Graph model (renderer / worker view)
// ---------------------------------------------------------------------------

export interface GraphNode {
  id: number;
  name: string;
  org?: number | string;
  role?: string;
  degree: number;
  /** Layout position, when computed/cached. */
  x?: number;
  y?: number;
  /** Louvain community, when computed. */
  community?: number;
}

export interface GraphLink {
  source: number;
  target: number;
  type: EdgeType;
  directed: boolean;
}

export interface GraphSnapshot {
  nodes: GraphNode[];
  links: GraphLink[];
}

// ---------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------

export interface SearchQuery {
  /** Raw user text; may contain operators (org:, tag:, near:, hops:). */
  text: string;
  /** Monotonic id for cancellation; results with a stale id are discarded. */
  requestId: number;
  limit?: number;
  /** Optional structured filters parsed from chips/operators. */
  filters?: SearchFilters;
}

export interface SearchFilters {
  org?: string;
  tags?: string[];
  edgeType?: EdgeType;
  hasEmail?: boolean;
  /** Graph-aware: restrict to N hops from a contact. */
  nearContactId?: number;
  hops?: number;
}

export interface SearchResult {
  contactId: number;
  name: string;
  org?: string;
  role?: string;
  degree: number;
  score: number;
  /** Character ranges to highlight, per field. */
  highlights?: { field: string; ranges: [number, number][] }[];
}

export interface SearchResponse {
  requestId: number;
  results: SearchResult[];
  /** Present when recall was empty; phonetic suggestion. */
  didYouMean?: string;
}

// ---------------------------------------------------------------------------
// Graph queries
// ---------------------------------------------------------------------------

export interface EgoQuery { contactId: number; depth: number; }
export interface PathQuery { fromId: number; toId: number; }
export interface PathResult { path: number[]; hops: number; found: boolean; }
export interface CentralityQuery { metric: "degree" | "betweenness"; }

// ---------------------------------------------------------------------------
// Backup / export
// ---------------------------------------------------------------------------

export interface BackupResult { path: string; createdAt: Timestamp; ok: boolean; }

export interface ExportOptions {
  destPath: string;
  /** When set, the archive is encrypted with a key derived from this. */
  passphrase?: string;
}

export interface ImportOptions {
  srcPath: string;
  passphrase?: string;
  /** How to handle contacts that match existing ones. */
  onDuplicate: "skip" | "merge" | "keepBoth";
}

export interface ImportReport {
  imported: number;
  merged: number;
  skipped: number;
  duplicatesFound: number;
  schemaVersion: number;
}

// ---------------------------------------------------------------------------
// IPC channel map — channel name → { request, response }
// ---------------------------------------------------------------------------

export interface IpcContract {
  "contacts:list": { request: { includeDeleted?: boolean }; response: Contact[] };
  "contacts:get": { request: { id: number }; response: Contact | null };
  "contacts:create": { request: { name: string; fields?: ContactFields }; response: Contact };
  "contacts:update": { request: { id: number; patch: Partial<Contact> }; response: Contact };
  "contacts:softDelete": { request: { id: number }; response: { id: number; deletedAt: Timestamp } };
  "contacts:restore": { request: { id: number }; response: Contact };

  "edges:create": { request: Omit<Edge, "createdAt">; response: Edge };
  "edges:delete": { request: { sourceId: number; targetId: number; type: EdgeType }; response: { ok: boolean } };

  "interactions:list": { request: { contactId: number }; response: Interaction[] };
  "interactions:add": { request: Omit<Interaction, "id">; response: Interaction };

  "graph:snapshot": { request: {}; response: GraphSnapshot };
  "graph:ego": { request: EgoQuery; response: number[] };
  "graph:path": { request: PathQuery; response: PathResult };
  "graph:centrality": { request: CentralityQuery; response: Record<number, number> };

  "search:query": { request: SearchQuery; response: SearchResponse };

  "backup:now": { request: {}; response: BackupResult };
  "export:archive": { request: ExportOptions; response: { path: string; ok: boolean } };
  "import:archive": { request: ImportOptions; response: ImportReport };
}

export type IpcChannel = keyof IpcContract;
export type IpcRequest<C extends IpcChannel> = IpcContract[C]["request"];
export type IpcResponse<C extends IpcChannel> = IpcContract[C]["response"];

/** Uniform error shape returned (rejected) across every channel. */
export interface IpcError {
  channel: IpcChannel;
  code: "VALIDATION" | "NOT_FOUND" | "CONFLICT" | "LOCKED" | "INTERNAL";
  message: string;
}
