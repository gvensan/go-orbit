// generate-fixture.js — build a realistic test database at target scale.
//
//   node scripts/generate-fixture.js [--contacts 20000] [--out test/fixtures/scale.db] [--key testkey] [--corrupt]
//
// Produces a migrated, populated DB used by the perf + acceptance suites.
// --corrupt writes a byte-damaged copy alongside it for self-heal tests.

const fs = require("fs");
const path = require("path");
const Database = require("better-sqlite3-multiple-ciphers");
const { migrate } = require("../src/main/db/migrate");

function arg(name, def) {
  const i = process.argv.indexOf(`--${name}`);
  return i > -1 ? process.argv[i + 1] : def;
}
const has = (name) => process.argv.includes(`--${name}`);

const N = parseInt(arg("contacts", "20000"), 10);
const OUT = arg("out", path.join(__dirname, "..", "test", "fixtures", "scale.db"));
const KEY = arg("key", "testkey");

function mulberry32(a) {
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
const rnd = mulberry32(1337);
const ri = (n) => Math.floor(rnd() * n);

const FIRST = ["Ava","Liam","Noah","Emma","Olivia","Mason","Mia","Ethan","Riya","Arjun","Wei","Priya","Diego","Yuki","Omar","Fatima","Kai","Nina","Zara","Ivan","Maya","Raj","Elena","Hana","Sven","Lucia","Amir","Grace","Tomas","Ines"];
const LAST = ["Chen","Patel","Kim","Garcia","Okafor","Nguyen","Silva","Haddad","Rossi","Novak","Khan","Torres","Ivanov","Tanaka","Mensah","Cohen","Reyes","Singh","Muller","Abbas"];
const ORGS = ["Acme Corp","Globex","Initech","Umbrella","Wayne Ent.","Hooli","Stark Ind.","Soylent"];
const ROLES = ["Eng Lead","Designer","PM","Founder","Analyst","Recruiter","Sales","Ops","Legal","Data Sci"];
const EDGE_TYPES = ["colleague","family","introduced","friend"];

function build() {
  fs.mkdirSync(path.dirname(OUT), { recursive: true });
  if (fs.existsSync(OUT)) fs.unlinkSync(OUT);

  const db = new Database(OUT);
  db.pragma(`key = '${KEY}'`);
  db.pragma("journal_mode = WAL");
  db.pragma("foreign_keys = ON");
  migrate(db, { backupDir: path.join(path.dirname(OUT), "backups") });

  const now = Date.now();
  const insC = db.prepare("INSERT INTO contacts (id,name,fields,created_at,updated_at) VALUES (?,?,?,?,?)");
  const insS = db.prepare("INSERT INTO contacts_search (id,name,email,phone,company,role,tags,notes) VALUES (?,?,?,?,?,?,?,?)");
  const insE = db.prepare("INSERT OR IGNORE INTO edges (source_id,target_id,type,directed,created_at) VALUES (?,?,?,?,?)");
  const insI = db.prepare("INSERT INTO interactions (contact_id,occurred_at,kind,note) VALUES (?,?,?,?)");

  const seed = db.transaction(() => {
    for (let i = 1; i <= N; i++) {
      const name = `${FIRST[ri(FIRST.length)]} ${LAST[ri(LAST.length)]}`;
      const company = ORGS[ri(ORGS.length)];
      const role = ROLES[ri(ROLES.length)];
      const email = name.toLowerCase().replace(/[^a-z]/g, ".") + "@" + company.split(" ")[0].toLowerCase() + ".com";
      const phone = `+1${1000000000 + ri(900000000)}`;
      const fields = JSON.stringify({ email, phone, company, role });
      insC.run(i, name, fields, now, now);
      insS.run(i, name, email, phone, company, role, "", "");
      if (rnd() < 0.4) insI.run(i, now - ri(180) * 86400000, "email", "auto-seeded");
    }
    // ~10 edges/node average
    for (let k = 0; k < N * 5; k++) {
      const a = 1 + ri(N), b = 1 + ri(N);
      if (a !== b) insE.run(Math.min(a, b), Math.max(a, b), EDGE_TYPES[ri(EDGE_TYPES.length)], 0, now);
    }
  });
  seed();

  const contacts = db.prepare("SELECT COUNT(*) c FROM contacts").get().c;
  const edges = db.prepare("SELECT COUNT(*) c FROM edges").get().c;
  db.pragma("wal_checkpoint(TRUNCATE)");
  db.close();
  console.log(`[fixture] ${OUT}: ${contacts} contacts, ${edges} edges`);

  if (has("corrupt")) {
    const bad = OUT.replace(/\.db$/, ".corrupt.db");
    fs.copyFileSync(OUT, bad);
    const fd = fs.openSync(bad, "r+");
    const size = fs.fstatSync(fd).size;
    const junk = Buffer.alloc(4096, 0xff);
    fs.writeSync(fd, junk, 0, junk.length, Math.floor(size / 2)); // damage the middle
    fs.closeSync(fd);
    console.log(`[fixture] corrupt copy: ${bad}`);
  }
}

build();
